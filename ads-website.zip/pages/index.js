
export default function Home() {
  return (
    <div style={{padding:"20px", fontFamily:"sans-serif"}}>
      <h1>مرحبا بك في الموقع</h1>

      <ins className="adsbygoogle"
        style={{ display: "block", marginTop:"20px" }}
        data-ad-client="ca-pub-1664033422008447"
        data-ad-slot="1234567890"
        data-ad-format="auto"
        data-full-width-responsive="true"></ins>

      <script>
        {(adsbygoogle = window.adsbygoogle || []).push({});}
      </script>
    </div>
  );
}
