# Waleed alkhulaqi Website

## 📌 المشروع يتكون من قسمين:
1. **الواجهة الأمامية (Frontend)** — React + Vite
2. **الخادم (Server Proxy)** — Express.js

---

## 🚀 التشغيل محلياً

### Frontend
```bash
cd frontend
npm install
npm run dev
```
يفتح على http://localhost:5173

### Server
```bash
cd server
npm install
# أنشئ ملف .env بناءً على .env.example
node index.js
```
الخادم يعمل على http://localhost:8080

---

## ☁️ النشر على Alibaba Cloud

### 1. الواجهة الأمامية (Frontend) على OSS
- أنشئ Bucket في **Alibaba Cloud OSS** (نوع Public Read).
- قم ببناء المشروع:
```bash
cd frontend
npm run build
```
- انسخ محتويات مجلد `dist/` إلى الـ Bucket (يمكن باستخدام أداة ossutil أو واجهة الويب).

- في إعدادات الـ Bucket، فعل **Static Website Hosting** وحدد:
  - Index Document = `index.html`
  - Error Document = `index.html`

- الآن سيكون الموقع متاح عبر رابط الـ OSS أو عبر نطاقك المربوط.

### 2. الخادم (Server) على Function Compute أو ECS

#### خيار A: Function Compute
- أنشئ Function جديد بلغة **Node.js 16/18**.
- ارفع محتويات مجلد `server/` (بما فيه `package.json` و `index.js`).
- أضف المتغيرات البيئية (Environment Variables) من لوحة التحكم:
  - `AI_API_KEY=...`
  - `AI_PROVIDER_URL=https://api.example-ai.example/v1/generate`
  - `PORT=9000` (أو أي منفذ تدعمه الخدمة)
- اربط Function Compute مع API Gateway أو Custom Domain ليصبح متاحاً عبر الإنترنت.

#### خيار B: ECS (Virtual Server)
- احجز ECS instance (Ubuntu/Debian).
- ثبت Node.js و npm.
- انسخ مجلد `server/` إلى الخادم.
- أضف ملف `.env` بالمفاتيح.
- شغل الخادم باستخدام:
```bash
node index.js
```
- يفضل استخدام **PM2** أو **systemd** لإدارة الخدمة بشكل دائم.
- اربط الـ ECS مع نطاقك عبر إعدادات DNS.

---

## 🔑 ملف البيئة (.env)
أنشئ ملف `.env` داخل مجلد `server/` بالمحتوى التالي:

```
AI_API_KEY=ak_01k22rc3x1e148dcgbk3d3jaj3
AI_PROVIDER_URL=https://api.example-ai.example/v1/generate
PORT=8080
```

⚠️ لا ترفع هذا الملف إلى أي مستودع عام.

---

## 🌐 ربط النطاق
- اربط النطاق **waleedalkhulaqi.website** بخدمة OSS (لواجهة الموقع).
- اجعل الخادم متاح عبر نطاق فرعي مثلاً: **api.waleedalkhulaqi.website** باستخدام Function Compute أو ECS.
- حدّث سجلات DNS من Alibaba Cloud Console.

---

## ✅ الخلاصة
- Frontend → Alibaba OSS + Static Website Hosting
- Server → Function Compute أو ECS
- DNS → يربط بين النطاق الرئيسي والـ Subdomain

---
