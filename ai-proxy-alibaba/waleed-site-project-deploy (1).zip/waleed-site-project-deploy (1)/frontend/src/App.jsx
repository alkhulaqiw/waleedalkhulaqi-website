import React, { useState } from 'react'

export default function App(){
  const [prompt, setPrompt] = useState('')
  const [output, setOutput] = useState('')

  const callAI = async () => {
    try{
      const res = await fetch('/api/ai/generate', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({prompt})
      })
      const data = await res.json()
      setOutput(JSON.stringify(data, null, 2))
    }catch(e){
      setOutput('خطأ في الطلب: '+ String(e))
    }
  }

  return (
    <div style={{fontFamily:'sans-serif',padding:20,maxWidth:900,margin:'0 auto'}}>
      <h1>Waleed alkhulaqi — موقع شخصي</h1>
      <p>حقل تجربة واجهة الذكاء الاصطناعي (يستخدم بروكسي الخادم).</p>
      <textarea rows={4} value={prompt} onChange={e=>setPrompt(e.target.value)} style={{width:'100%'}} />
      <div style={{marginTop:8}}>
        <button onClick={callAI}>اطلب الذكاء</button>
      </div>
      <pre style={{whiteSpace:'pre-wrap',marginTop:12,background:'#f7f7f7',padding:12}}>{output}</pre>
    </div>
  )
}
