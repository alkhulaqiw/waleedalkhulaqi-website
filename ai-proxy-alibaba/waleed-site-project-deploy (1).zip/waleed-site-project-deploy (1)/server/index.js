import express from 'express'
import fetch from 'node-fetch'
import dotenv from 'dotenv'

dotenv.config()
const app = express()
app.use(express.json())

const PORT = process.env.PORT || 8080
const AI_API_KEY = process.env.AI_API_KEY
const AI_PROVIDER_URL = process.env.AI_PROVIDER_URL || 'https://api.example-ai.example/v1/generate'

if(!AI_API_KEY) console.warn('Warning: AI_API_KEY not set in environment. Requests will fail.')

app.post('/api/ai/generate', async (req, res) => {
  try{
    const { prompt } = req.body
    if(!prompt) return res.status(400).json({error:'missing prompt'})

    const response = await fetch(AI_PROVIDER_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${AI_API_KEY}`
      },
      body: JSON.stringify({ input: prompt })
    })

    if(!response.ok){
      const text = await response.text()
      return res.status(response.status).send(text)
    }

    const data = await response.json()
    return res.json(data)
  }catch(err){
    console.error(err)
    return res.status(500).json({error: String(err)})
  }
})

app.listen(PORT, ()=> console.log('AI proxy running on', PORT))
