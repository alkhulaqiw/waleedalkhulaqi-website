module.exports = {
  content: ["./app/**/*.{js,jsx}"],
  theme: { extend: {} },
  plugins: [],
};