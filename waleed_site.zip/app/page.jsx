
export default function Home() {
  return (
    <main className="min-h-screen p-8 bg-gray-50">
      <section className="text-center py-20">
        <h1 className="text-4xl font-bold mb-4">موقع وليد الخلاقي</h1>
        <p className="text-lg text-gray-600">إعادة تصميم كاملة من الألف إلى الياء</p>
      </section>
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10">
        <div className="p-6 bg-white shadow rounded-xl">المقالات</div>
        <div className="p-6 bg-white shadow rounded-xl">الوسائط</div>
        <div className="p-6 bg-white shadow rounded-xl">أدوات الذكاء</div>
      </section>
    </main>
  );
}
