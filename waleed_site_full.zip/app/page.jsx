
import Link from "next/link";

export default function Home(){
  return (
    <main className="py-20 text-center">
      <h1 className="text-4xl font-bold mb-3">موقع وليد الخلاقي</h1>
      <p className="text-gray-600 mb-8">نسخة مطورة — مقالات — وسائط — أدوات ذكاء</p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link href="/articles" className="p-6 bg-white shadow rounded-xl">📘 المقالات</Link>
        <Link href="/media" className="p-6 bg-white shadow rounded-xl">🎞 الوسائط</Link>
        <Link href="/tools" className="p-6 bg-white shadow rounded-xl">🤖 أدوات الذكاء</Link>
      </div>
    </main>
  );
}
