
export const metadata = { title: "موقع وليد الخلاقي" };

export default function RootLayout({ children }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-gray-50">
        <div className="max-w-5xl mx-auto p-4">
          {children}
        </div>
      </body>
    </html>
  );
}
