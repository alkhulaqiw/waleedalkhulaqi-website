
import fs from "fs";
import path from "path";
import matter from "gray-matter";
import { remark } from "remark";
import html from "remark-html";

export default async function Article({ params }){
  const file = fs.readFileSync(path.join("articles",params.slug+".md"),"utf8");
  const { data, content } = matter(file);
  const processed = await remark().use(html).process(content);
  const htmlContent = processed.toString();

  return (
    <article className="prose prose-lg max-w-none" dangerouslySetInnerHTML={{ __html: htmlContent }} />
  );
}
