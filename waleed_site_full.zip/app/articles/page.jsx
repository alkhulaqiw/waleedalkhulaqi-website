
import fs from "fs";
import path from "path";
import Link from "next/link";
import matter from "gray-matter";

export default function Articles(){
  const files = fs.readdirSync(path.join(process.cwd(),"articles"));
  const posts = files.map(filename=>{
    const content = fs.readFileSync(path.join("articles",filename),"utf8");
    const { data } = matter(content);
    return { slug: filename.replace(".md",""), title:data.title };
  });

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">📘 المقالات</h1>
      <ul className="space-y-4">
        {posts.map(p=>(
          <li key={p.slug}>
            <Link href={`/articles/${p.slug}`} className="text-blue-600 underline">{p.title}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
